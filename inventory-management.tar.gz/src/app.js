const express = require('express');
const app = express();
const db = require('../config/database'); // Connect to your database
const Product = require('./modules/product'); // Import models so Sequelize knows about them
const Sale = require('./modules/sales');
//const Category = require('./modules/category'); // if you have it too

// Import route modules
const productRoutes = require('./routes/productRoutes');
const salesRoutes = require('./routes/salesRoutes');
const authRoutes = require('./routes/authRoutes');
const categoryRoutes = require('./routes/categoryRoutes'); // New routes for product categories

// Middleware: Parse JSON payloads
app.use(express.json());

// Route registration
app.use('/api/products', productRoutes);
app.use('/api/sales', salesRoutes);
app.use('/api/auth', authRoutes);
app.use('/api/categories', categoryRoutes);

// Health check route
app.get('/', (req, res) => {
  res.send('✅ Welcome to the Inventory Management System API!');
});

// --- 🛠️ Sync the database ---
const syncDatabase = async () => {
  try {
    await sequelize.sync({ force: false }); 
    console.log('✅ Database synced!');
  } catch (error) {
    console.error('❌ Error syncing database:', error);
  }
};

syncDatabase();
// --- End of sync setup ---

module.exports = app;
