const { DataTypes } = require('sequelize');
// new (two levels up — correct)
const sequelize = require('../../config/database');   // Make sure your DB config path is correct

const Product = sequelize.define('Product', {
  id: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true,
  },
  name: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  stock: {
    type: DataTypes.INTEGER,
    allowNull: false,
    defaultValue: 0,
  },
}, {
  tableName: 'products',
  timestamps: false, // Set true if you want createdAt, updatedAt
});

module.exports = Product;
