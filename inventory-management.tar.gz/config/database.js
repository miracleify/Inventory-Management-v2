// config/database.js
require('dotenv').config();
const { Sequelize } = require('sequelize');
const config = require('./config');

const sequelize = new Sequelize(config.dbName, config.dbUser, config.dbPassword, {
  host: config.dbHost,
  port: config.dbPort,
  dialect: 'postgres',
  dialectOptions: config.dbSSL === 'true' ? { ssl: { require: true, rejectUnauthorized: false } } : {},
  logging: false, // turn off SQL logs in the console
});

sequelize.authenticate()
  .then(() => {
    console.log('✅ Connected to the PostgreSQL database (via Sequelize)');
  })
  .catch(err => {
    console.error('❌ Unable to connect to the database:', err);
  });

module.exports = sequelize;
